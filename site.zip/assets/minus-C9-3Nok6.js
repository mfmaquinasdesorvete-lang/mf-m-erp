import{t as s}from"./index-AveP7AMK.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=s("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{a as M};

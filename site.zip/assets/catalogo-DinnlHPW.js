function o(e){return e.foto?Number(e.preco)>0?"":"sem preço de venda":"sem foto"}export{o as p};

import{n as i,j as e,ad as r}from"./index-Dy7WFO4t.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=i("Filter",[["polygon",{points:"22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3",key:"1yg77f"}]]);function l({destaque:s,mostrando:t,onLimpar:n}){return e.jsxs("div",{role:"status",className:"mb-3 flex flex-wrap items-center gap-x-3 gap-y-2 rounded-xl border border-sky-200 bg-sky-50 px-3 py-2 text-sm text-sky-900",children:[e.jsx(o,{size:16,"aria-hidden":!0,className:"shrink-0"}),e.jsxs("span",{className:"min-w-0 flex-1",children:[e.jsxs("b",{children:[s.origem,":"]})," ",s.titulo||"itens apontados"," · mostrando ",t," de ",s.ids.length]}),e.jsxs("button",{type:"button",onClick:n,className:"inline-flex items-center gap-1 font-semibold underline-offset-2 hover:underline",children:[e.jsx(r,{size:14,"aria-hidden":!0})," Ver todos"]})]})}export{l as F};
